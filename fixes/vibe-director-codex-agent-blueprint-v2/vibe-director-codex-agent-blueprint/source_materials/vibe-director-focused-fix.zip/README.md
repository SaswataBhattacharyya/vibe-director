# Vibe Director focused repair — November 2026

Owner clarification: existing **left navigation** and **Media Prep** are good; preserve them. Focus on Production Type & Style, screenplay, storyboard, Prompt Preparation, Video Create and the shared Director/Editor tool gateway.

Contents:
- `docs/FOCUSED_REPAIR_PLAN.md` — detailed decisions, phases, tests and source touchpoints.
- `skills/production-style-director/SKILL.md` — seventh skill to interpret production type vs visual style vs directing language; optional creative guidance.
- `docs/CODEX_FIRST_IMPLEMENTATION_PROMPT.md` — safe initial Codex implementation brief.
- `existing_six_skills/` — copies of the original six skills (if packaged).

The source review and glossary remain separately available in the earlier redesign pack. This pack is a focused addendum; **no live app code has been modified**.
