# Vibe Director — Six-Skill Starter Pack (v1.0)

**Status:** Ready-to-integrate *skill definitions*, **not yet connected to the application**. The user will supply a Markdown app audit and source ZIP; map tool adapters only after reviewing them.

## Skills

| Folder | Purpose |
| --- | --- |
| `skills/screenplay-writer/SKILL.md` | Screenplay, dialogue, realistic timing and clip breakdown |
| `skills/character-designer/SKILL.md` | Character bible and Z-Image reference prompts |
| `skills/environment-designer/SKILL.md` | Location bible, spatial layout and Z-Image backgrounds |
| `skills/storyboard-director/SKILL.md` | Fast comic-style visual panels with dialogue/timing |
| `skills/cinematic-prompt-director/SKILL.md` | Model-aware video prompts with reference uploads, timestamps, audio and camera |
| `skills/continuity-director/SKILL.md` | Character/prop/camera/first-frame continuity between clips |

Each folder uses the standard YAML-frontmatter `SKILL.md` convention.

## Additional integration files
- `DIRECTOR_SYSTEM_PROMPT.md`: Copyable starting instructions for the in-app Director chat.
- `DIRECTOR_INTEGRATION.md`: How to give chat access to every actual app component.
- `shared/CONTRACT.md`: Common data, safety, tool usage and reference semantics.
- `shared/project.schema.json`: Extensible project-state schema (starter only).
- `shared/capability-registry.example.json`: Unmapped tool registry example, intentionally marked unavailable.
- `examples/scene5-rescue.json`: Concrete storyboard/clip/voice-reference handoff example.
- `scripts/validate_video_prompt.py`: Optional prompt length, duration, beat coverage and slot-check helper.

## How to integrate later
1. Place the six skill folders in the host application's skill loader directory (for Codex-style environments, often `.agents/skills/`), or register the directories with your agent framework.
2. Configure the chat Director with `DIRECTOR_SYSTEM_PROMPT.md` and `shared/CONTRACT.md`.
3. Expose *actual* app capabilities as typed callable tools; register every safe component the Director should be allowed to use. **Skill instructions do not themselves connect tools.**
4. Feed the active project/selection, approved assets, model profiles, job status and settings to every chat turn.
5. Integrate prompts, storyboards, media and editor state without locking the user into a predefined workflow.
6. After reviewing the actual app, replace the example capability mappings and adapt the starter schema to the existing database instead of migrating blindly.

## Current Vibe Director project constraints
For **MiniMax H3 as configured by the user**: 15 seconds maximum per video, 7,000 characters maximum for the complete video-generation prompt. Model-specific compatibility must be checked rather than assumed. TTS Audio Suite WAVs are **voice identity samples**, not dialogue recordings. When two clips continue at the same moment, the previous last frame is a candidate for the new first frame; it is not obligatory for a time jump. LTX Upscaling must be able to be actually switched OFF.
