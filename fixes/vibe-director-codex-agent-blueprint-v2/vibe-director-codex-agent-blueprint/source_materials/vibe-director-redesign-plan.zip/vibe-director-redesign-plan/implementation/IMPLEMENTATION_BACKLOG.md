# Executable Implementation Backlog — Sequenced Milestones

This is a proposed backlog for a coding agent and maintainer. Paths come from the uploaded source review/glossary; **verify the actual repository checkout before any edits**. No ticket means “rewrite the whole app.” Preserve existing tests and run versioned schema migrations only when justified.

## Milestone 0 — Baseline safety and source reconciliation (no feature refactor)

- [ ] **M0-01:** Record branch, commit, working-tree diff, running services, actual installed ComfyUI nodes/graphs, HyperFrames package/version, and Python/Node/FFmpeg versions. Do not discard uncommitted changes.
- [ ] **M0-02:** Preserve test project/checkpoint, DB/ledger, media hashes, output artifacts, and a non-mutating screenshot/recording of current UI flows. Document backup restoration.
- [ ] **M0-03:** Re-run existing focused tests for manual T2V/R2V/FFLF admission, media replacement, project selection, storyboard, editor and assembly. Separate mocked, CPU, and real GPU tests.
- [ ] **M0-04:** Audit `tool_glossary/catalog.json` (44 groups) against source/API validators. Mark each operation `callable`, `navigation_only`, `unwired`, `unavailable`, and `requires_runtime_probe`.
- [ ] **M0-05:** Produce a dependency map for `App.tsx`, `isolated_server.py`, `director_skills.py`, editor command handling, LTX pipeline; choose narrow adapter insertion points.

**Acceptance:** baseline behavior and known failures documented; restores possible; no submitted jobs or original asset hashes changed.

## Milestone 1 — Codex-style shell (front-end only + context bridge)

- [ ] **M1-01:** Extract `WorkspaceShell` around `StudioShell.tsx`; project/navigation left, persistent Director center, work-surface right. Feature flag and preserve existing standalone routes.
- [ ] **M1-02:** Support resizable/collapsible panels, focus order, smaller screens, tabbed right-pane views and unsaved-edit warnings.
- [ ] **M1-03:** Introduce typed `OpenSurface` context actions for **existing** pages: Story, Screenplay, Image, Storyboard, Video, Media Prep, Editor, Jobs.
- [ ] **M1-04:** Project-scoped persistent conversation selection and chat input/attachment state; do not let project A messages/asset IDs appear in B.
- [ ] **M1-05:** Real activity status for reasoning/job operations, with cancellation/approval controls only where supported.

**Relevant source:** `StudioShell.tsx`, `App.tsx`, `ProjectController.tsx`, existing pages and project-state persistence.

**Acceptance:** user can switch right pages and back without losing chat or selected media; project switch fences old task responses; manual Video Create still works unchanged.

## Milestone 2 — Real Director tool gateway + first vertical slice

- [ ] **M2-01:** Add per-operation registry `tool.list/describe`, backed by actual validation schemas, live capability probes and explicit type/permission classification.
- [ ] **M2-02:** Add server-side typed tool executor with project/session ownership guard, logging, request/result schema validation and existing service adapters. No arbitrary URL/shell action.
- [ ] **M2-03:** Agent loop invokes read-only registry + limited working operations, persists a Director Task, streams native job state, and reuses real job IDs on retries.
- [ ] **M2-04:** Implement `audio.extract_mp3.start/status` using existing Audio Utilities (not a duplicate MP3 implementation). Bridge selected Editor media and show the playable result in chat/right pane.
- [ ] **M2-05:** Add `navigation.open` and `asset.preview/select` operations; the Director must open an interactive existing page, not describe an imaginary click.
- [ ] **M2-06:** Update existing Editor specialist rules and Director skill loader so a renderer limitation isn't treated as an app-wide limitation.

**Relevant source:** `director_skills.py`, `reasoning_provider.py`, `vibe_editor.py`, `vibe_editor_api.py`, `MediaPrepPage.tsx`, `media-api.ts`, `audio_utilities.py`, backend dispatcher.

**Acceptance:** complete requested MP3 extraction via chat; selected source shown in real Audio Tool; output returned to correct project/session; browser refresh resumes status; no duplicate job from lost response.

## Milestone 3 — Six skills and model-aware prompt composer

- [ ] **M3-01:** Register the six skill directories; load on demand; show which creative skill/model profile is in use without dumping huge skill text into chat.
- [ ] **M3-02:** Connect Z-Image character/world prompt generation to existing Image service; keep prompt version, approved master, location/identity ID and actual asset selection separate.
- [ ] **M3-03:** Create shared model capability profiles from actual T2V/R2V/FFLF backend contracts; UI and Director use one profile provider.
- [ ] **M3-04:** Implement reference manifest builder with stable asset ID/hash and independently numbered `<Picture>`, `<Video>`, `<audio>` slots; show thumbnail and per-reference instructions.
- [ ] **M3-05:** Timecoded beat editor with camera/gesture/audio/dialogue, shot-end continuity policy and voice-sample-only semantics.
- [ ] **M3-06:** Prompt compiler/linter: strict codepoint length `< 7000`, R2V max 15s, 9/3/3 limits, FFLF both frames, T2V empty refs; raw final prompt editing preserved.
- [ ] **M3-07:** Route generated prompt to existing Video Create with exact route-specific request, then actual validation before Generate; never invent a generic JSON union.

**Relevant source:** `prompt_drafts.py`, `prompt_director.py`, `workflow_knowledge.py`, `isolated_*_contract.py`, `video-api.ts`, `PromptPreparationPage.tsx`, `App.tsx`.

**Acceptance:** Lion-and-Mouse 15s clip yields explicit reference upload table, realistic timecodes, voice identity slots, <7000 codepoints, one-click draft handoff, no screenplay prerequisite.

## Milestone 4 — Comic-book storyboard

- [ ] **M4-01:** Reuse current board/screensplay scene/shot records; define lightweight per-panel projection with image, beat, dialogue, duration, camera, reference IDs, `clipGroupId`.
- [ ] **M4-02:** Create comic grid with panels, dialogue outside images, drag-reorder and selective prompt edit/regenerate/approve.
- [ ] **M4-03:** Integrate quick batch image generation and selection with Z-Image/Qwen; use canonical char/world IDs where present but allow standalone image-based board.
- [ ] **M4-04:** Move any multi-shot auto-image loop from browser ownership to durable backend task dependencies; browser closure must not stop progression unexpectedly.
- [ ] **M4-05:** Hand off scene/panel group to video prompt studio, image holds or Editor; preserve existing storyboard HTML export, optionally enhance export later.

**Relevant source:** `StoryboardPage.tsx`, `storyboard.py`, `ImageAssetsPage.tsx`, `production_image_jobs.py`.

**Acceptance:** comic page for full story with images, action, dialogue and time; regenerate a single panel; editor receives selected actual media; no forced accepted screenplay for a separate manual request.

## Milestone 5 — Video utilities, true LTX OFF and durable mixed task graph

- [ ] **M5-01:** Audit existing `/api/video/jobs/{id}/continuity-frame` and generalize first/last/at-time extraction for project imported videos only if needed. Register images as versioned assets; no overwrites.
- [ ] **M5-02:** Define `postprocessPolicy=original|refined` in a versioned admissible envelope/contract, not as a stray field on strict nested workflows.
- [ ] **M5-03:** Worker bypass for original-only path, collecting verified H3 video+audio, trimming frame alignment and marking actual quality. Keep enhanced v2 jobs unchanged.
- [ ] **M5-04:** Quality choice reflected across manual, batch, retake and automated production paths with one shared policy provider. Full render preflight distinguishes Turbo readiness vs LTX readiness.
- [ ] **M5-05:** Implement one actionable blocker-report endpoint/selector merging draft errors, capability, pending attempt, active job, GPU hold, strict plan stale, editor approval.
- [ ] **M5-06:** Add new revisioned, optional `ProductionDocument`/task graph over existing scenes/shots/panel/media and mixed routes. Maintain old run manifest support. Backend advances runs; no hardbound browser wizard.
- [ ] **M5-07:** Add reconciliation tests for lost server reply, resumed work, source asset replacement, and two project contexts.

**Relevant source:** `isolated_video_jobs.py`, `production_job_worker.py`, `t2v_pipeline.py`, `ltx_chunks.py`, `production_ledger.py`, `fully_automated_clip_plan.py`, `production_setup.py`, `media_discovery.py`, `isolated_video_contract.py`.

**Acceptance:** LTX OFF produces verified Turbo original with intact original audio and zero LTX chunk jobs; old enhanced jobs retain correct recovery; mixed scene can be manually/automatically routed without forcing story approval.

## Milestone 6 — Editor, HyperFrames and flexible output

- [ ] **M6-01:** Move current Vibe Editor interactive controls under right-pane while keeping ongoing chat left/center; project session handoff uses real selected asset IDs/ranges.
- [ ] **M6-02:** Add freeform timeline draft supporting images (duration holds), generated clips, imported footage and audio placements, with non-destructive revisions. Translate to existing Editor plan where legal.
- [ ] **M6-03:** Preserve strict screenplay accepted-take assembly separately, explicitly label it `Screenplay Assembly`.
- [ ] **M6-04:** HyperFrames Studio feasibility branch: inspect current installed package/export API, build preview/timeline PoC, test project/media roundtrip, publish vetted render; abandon or isolate if incompatible.
- [ ] **M6-05:** Add Run Board based on **Vibe Director** ledger and events (Backlot-inspired), separate from editable comic storyboard.
- [ ] **M6-06:** Export acceptance with original audio policy, correct file collisions, video probe, project ownership and output folder grant.

**Relevant source:** `VibeEditorPage.tsx`, `EditorWorkspace.tsx`, `vibe_editor.py`, `vibe_editor_render.py`, `assembly.py`, `assembly_renderer.py`, `output_destinations.py`.

**Acceptance:** timeline from generated clips/stills, persistent chat and usable preview, supported render and verified export. Not just “opened editor” text.

## Milestone 7 — Full regression, rollout and optional adapters

- [ ] **M7-01:** Browser E2E tests for each entry point: story, character, storyboard, prompt, uploaded clip, voice sample, Editor-only.
- [ ] **M7-02:** API schema contract tests for every routed tool and mode; frozen historic inputs still parse/recover.
- [ ] **M7-03:** Project checkpoint/restore, A/B isolation, duplicate prevention, media replacement, stale GUI state and GPU safety tests.
- [ ] **M7-04:** Controlled actual video/image/editor acceptance in supported local environment, with pinned node version and video+audio probes. Not inferred from CPU mocks.
- [ ] **M7-05:** Optional OpenMontage research/footage bridge only after a license/security and added-value study; optional external Backlot view only after data-translation tests.
- [ ] **M7-06:** Keep feature flags/rollback, log real UX and quality defects, remove legacy paths only after parity.

**Acceptance:** all scenario checks listed in `MASTER_FIX_PLAN.md` §13 pass on the audited build; blocked work explains how to recover instead of dead-ending the user.

## Prioritization policy

**Fix first:** lost project/chat/context, inability to call tools, incorrect contract serialization, pending-attempt freezes, LTX bypass request, reference truth.  
**Then improve:** comic board speed, complex automation, HyperFrames Studio.  
**Defer:** external tool repo embedding and ambitious all-in-one full automation until the basic manual+Director slice is reliable.
