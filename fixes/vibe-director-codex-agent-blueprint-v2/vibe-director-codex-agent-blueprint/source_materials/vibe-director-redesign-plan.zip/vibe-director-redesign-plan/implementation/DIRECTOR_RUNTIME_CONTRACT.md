# Director Runtime Contract — Skills, Tools, State and Models

This is a **target specification**, not an assertion that the current app exposes these APIs. Verify against current backend/TS schemas before implementing. All proposed function names below are examples of *new app-level tool actions*; never send them directly to today's `/api/*` endpoints.

## 1. Director orchestration loop

```text
user/selection → resolve owner & state → choose skill(s) → discover real operation(s)
  → fetch schemas/capabilities → build draft / ask only essential missing info
  → authorize side effects → execute through backend adapter
  → stream actual job events → attach output IDs → update right pane/project
  → verify user outcome and stop OR explain the precise remaining blocker
```

One conversational Director routes work for the entire app. Vibe Editor, Prompt Director and Screenplay Director can supply specialist prompts/models but **share the same trusted tool gateway and project context**. A skill is a filmmaking instruction, not a permission to execute hidden Python/shell or bypass a workflow contract.

## 2. Runtime skill router

Selected package: `source_materials/vibe-director-six-skills.zip`.

| User goal | Load creative skills | Additional tool guides on demand |
|---|---|---|
| Screenplay from story | screenplay-writer | `02_STORY_AND_PROMPTS.md` |
| Z-Image consistent character | character-designer, continuity-director | `03_IMAGES.md` |
| Z-Image location and background | environment-designer, continuity-director | `03_IMAGES.md` |
| Comic storyboard | storyboard-director, continuity-director | `02_STORY_AND_PROMPTS.md`, `03_IMAGES.md` |
| Next R2V H3 clip | cinematic-prompt-director, continuity-director | `04_VIDEO.md`, `05_MEDIA_AND_SEARCH.md` |
| Video audio extraction/editing | relevant tool-domain guide + existing Editor rules | `06_AUDIO_AND_MUSIC.md`, `07_EDITOR.md` |

A short top-level Director contract and a minimal tool *index* are loaded per turn. Load targeted skill body and a tiny operation schema only after tool selection. Do not paste 700+ external skills and all 44 capability groups into every prompt. Update `director_skills.py` and the Editor specialist skill loader together; tests must show which skills were loaded for each task and in what version. Project-scoped learned prompt guidance remains separate from global skills.

## 3. Tool registry — 44 groups are not 44 callables

The glossary is an excellent *discovery index*. Convert groups into **small typed operation definitions**. Example conceptual registry:

```json
{
  "id": "audio.extract_mp3.start",
  "version": 1,
  "domain": "audio.extract",
  "description": "Extract MP3 from a registered video or audio asset",
  "inputSchema": {
    "type": "object",
    "properties": {
      "workspaceId": {"type": "string"},
      "sourceAssetId": {"type": "string"},
      "quality": {"type": "integer", "minimum": 0, "maximum": 9}
    },
    "required": ["workspaceId", "sourceAssetId"],
    "additionalProperties": false
  },
  "executionClass": "cpu_media",
  "readinessResolver": "existing audio utility capability adapter",
  "serviceAdapter": "existing createAudioUtilityJob wrapper",
  "uiTarget": "media-prep.audio-utilities",
  "jobLifecycle": ["create", "status"],
  "outputKind": "audio"
}
```

**Illustrative only:** exact `quality` range/settings schema must be copied from the installed validator, not inferred from this example. The tool gateway should validate request bytes/ownership and forward to the **same service methods** as the UI, with proper namespace/authorization.

### Essential initial actions

| Proposed operation | Underlying existing capability | Notes |
|---|---|---|
| `project.current.read`, `project.open`, `project.save` | ProjectController and `/api/projects/*` | Preserve checkpoint/idle logic. |
| `media.find`, `media.asset.read`, `media.asset.reuse` | media catalogue/search/reuse | Project owner and hashes always checked. |
| `image.generate.prepare`, `image.generate.start/status` | image validations/jobs/batches | Z-Image config from live workflow profile. |
| `video.prompt.validate`, `video.job.start/status` | `/api/video/validations`, `/api/video/jobs` | Exact T2V vs R2V vs FFLF request schema. |
| `video.continuity_frame.create` | `/api/video/jobs/{id}/continuity-frame` | For eligible saved/generated takes only, verify semantics. |
| `media.frame.extract` | **New generalized adapter needed if imported videos unsupported** | First/last/at-time, register a new image asset. |
| `audio.extract_mp3.start/status` | existing `/api/audio/{workspace}/utilities/jobs` | First complete vertical slice. |
| `story.screenplay.propose/apply` | story/screenplay services | Never apply unreviewed mutating proposals. |
| `storyboard.panel.create/update/regenerate` | board + image services | New granular operations may be necessary. |
| `editor.session.open`, `editor.plan.propose`, `editor.render.start/status`, `editor.export` | current Editor APIs | Preserve the two stages of approval unless new policy explicitly replaces them. |
| `navigation.open` | **New shell bridge** | Must open actual interactive work surface; no raw URL concatenation. |
| `runtime.blockers.read` | capability/job/runtime status aggregators | Return reasons and recovery actions. |

Subsequently add operations across the other glossary groups: semantic indexing, video summarizer, TTS, voice binding, music, Foley, 3D, time-range extraction, take review and assembly. Training/destructive operations need more restrictive policies and are not first-tier chat tools.

## 4. Access and authorization

| Class | Examples | Permission pattern |
|---|---|---|
| Read/status | browse/search project media, inspect job | Allowed within current project/tool owner |
| Navigate/populate | open prompt/editor with selected assets | Allowed; do not overwrite dirty drafts |
| Draft/propose | create screenplay/prompt candidate, editor plan | Allowed; retain version and user editability |
| CPU transformation | extract MP3/last frame, analyze supported source | User task request authorizes ordinary reversible action; visible job and output |
| Expensive generation | Z-Image, H3 R2V, speech/music generation, multi-clip run | Follow app's user intent, provider/GPU admission and chosen auto/assisted policies; cost/quality disclosure |
| Destructive/export | archive/delete original, overwrite output, model training or sensitive actions | Explicit approval, path/owner checks, versioned audit |

No single generic `call_url` or `run_shell` tool for the model. The model may select registered `tool_id` and typed arguments. Backend service owns validation, project checks, idempotency and execution guards. Never bypass a blocked GPU/worker with browser click automation.

## 5. Context envelopes and persistence

Persist task and conversation separately but link them:

```json
{
  "conversationId": "<uuid>",
  "turnId": "<uuid>",
  "projectId": "<actual-workspace-id>",
  "activeSurface": "editor.timeline",
  "editorSessionId": "<id-or-null>",
  "selection": {
    "assetIds": ["<registered-id>"],
    "ranges": [{"assetId": "<id>", "startMs": 0, "endMs": 5000}],
    "shotId": null,
    "clipDraftId": null
  },
  "modelProfileId": "minimax_h3_r2v_current",
  "taskId": "<uuid>",
  "revision": 12
}
```

A project switch must fence old callbacks/results and restore that project's conversation, drafts, selected assets, editor session, and active jobs atomically. The job state is not kept only in browser memory. Project Save/Load must include or be able to recreate the conversation/task *pointers* and owned artifacts, respecting existing snapshot behavior. Never move another project's media ID into a new owner's task implicitly.

### Director task statuses

`draft → proposed → authorized → queued → running → completed/needs_review/failed/cancelled/recovery_required`. Individual steps can have other native job statuses; this top-level state is only a task **projection**, not a competing job ledger. A task with three subtasks is not `completed` after step 1. Store `subtaskId`, `toolId`, immutable `argumentsHash`, `idempotencyKey` when supported, `nativeJobId`, project ID, resultAssetIds and events.

Use SSE or WebSocket progress **fed from durable backend job/event state**, with poll fallback. An exhausted stream reconnects with a last-event cursor. Never retry ambiguous GPU submissions without existing `by-idempotency` reconciliation/release path.

## 6. Shared surface navigation contract

Proposed `navigation.open` arguments:

```json
{
  "target": "editor.timeline",
  "projectId": "<real-project-id>",
  "conversationId": "<thread-id>",
  "assetIds": ["<selected-id>"],
  "selectedRanges": [{"assetId": "<id>", "startSeconds": 2.0, "endSeconds": 6.0}],
  "sessionId": "<existing-or-null>",
  "draftId": null,
  "openMode": "reuse_or_new_tab"
}
```

UI router resolves a **named page component** and `canAdoptContext()` contract. It must show selected source, settings and result. Backend remains source of truth. On dirty draft, prompt user to keep/swap tabs; never silently clear. Vibe Director's right pane should not substitute a screenshot for live Editor.

## 7. Model profiles and reference manifest compiler

Version model profiles in a read-only service rather than hardcoding names/limits throughout React:

```json
{
  "profileId": "minimax_h3_r2v_current",
  "workflowId": "minimax_h3_r2v_dynamic_v1",
  "duration": {"minSeconds": 5, "maxSeconds": 15},
  "prompt": {"maxExclusiveCodepoints": 7000},
  "references": {"imagesMax": 9, "videosMax": 3, "audiosMax": 3},
  "semanticControls": {"hardFirstFrame": false, "openingImageReference": true},
  "postprocessModes": ["turbo_original", "ltx_refined"]
}
```

**Illustrative profile**, not a newly implemented backend capability. Only publish `postprocessModes` after its versioned worker path works. T2V audit: 5–30s, empty refs. FFLF audit: 5–15s and **both** first/last frame asset/hash pairs; its request doesn't accept R2V `images/videos/audios` fields.

### Reference binding structure

```json
{
  "clipDraftId": "<draft>",
  "references": [
    {"slot": "<Picture 1>", "kind": "image", "assetId": "<mouse>", "purpose": "mouse_identity"},
    {"slot": "<Picture 2>", "kind": "image", "assetId": "<lion>", "purpose": "lion_identity"},
    {"slot": "<Picture 3>", "kind": "image", "assetId": "<lastframe>", "purpose": "opening_composition_reference"},
    {"slot": "<audio1>", "kind": "audio", "assetId": "<lion_voice>", "purpose": "lion_voice_identity_sample"}
  ],
  "dialogue": [{"speakerCharacterId": "<lion-id>", "text": "You saved me!", "voiceSlot": "<audio1>", "startS": 12, "endS": 15}]
}
```

Types and `role/intent` compiler fields must be translated by specific verified adapters; the user's `<Picture>/<audio>` tokens are human-facing prompt aliases only. The reference compiler must:
1. Count images, videos, audios **independently** in the selected display order.
2. Produce actual hash/asset mappings for the chosen engine, not infer from prose.
3. Reject dangling/duplicate/unsupported tags and mismatched audio/speaker bindings.
4. Keep existing selected reference ordering during edits unless user changes it deliberately; warn before re-collating and replacing pasted text.
5. Validate dialogue time ranges, estimated speaking duration, shot blocking and end-state.
6. Count Unicode code points and enforce **`len(prompt) < 7000`** for current H3; prompt with exactly 7,000 is invalid according to the review.
7. Verify duration against **selected mode** at generation time, not generic setup max.
8. Mark first-frame intent as an **R2V image reference** if that route doesn't expose a literal first-frame conditioning slot. Never claim hard guarantee.
9. Distinguish `<audio>` as **identity reference** from finished dialogue on a timeline. Generating words with a sample depends on actual selected workflow capabilities; no invented lip-sync guarantee.

## 8. True LTX bypass contract

Target: frozen render policy linked to job/take, **without adding unknown fields to today's strict nested T2V/R2V/FFLF request objects**.

```text
selected quality policy
       ├── turbo_original: H3 → collect original → verify/trim/mux → publish label
       └── ltx_refined:   H3 → LTX plan/chunks → stitch/trim/remux → verify/publish
```

Possible implementation placement: versioned top-level submission envelope or a new workflow/request contract. Confirm `isolated_video_jobs.py` dispatch, `production_job_worker.py` state machine and `t2v_pipeline.py` collection/admission before choosing. Freeze policy at job creation; existing v2 requests remain refined. Ensure recovered originals and published assets don't share the label/path/digest of enhanced outputs. UI toggles and automation manifests must use **one shared capability policy**.

## 9. Source of truth and review policy

- Manual clip prompt/frozen request is real generation input; screenplay suggestions are advisory.
- Strict accepted screenplay, frozen plan, accepted takes remain truth for strict automated/assembly flows.
- Screenshots, inferred image analysis and chat summaries are not proven asset identity/authoritative execution state.
- Voice references do not prove exact spoken words in output; review real audio where supported.
- Renderer output validation proves technical correctness (bytes/duration/audio), not successful acting, content or continuity. Present QA results without claiming human-quality approval.

## 10. First vertical slice: tests and workflow

**Request:** “In the Editor, extract this video's MP3 and show it here.”

1. Resolve current project + selected *actual* video asset ID, distinguishing full source from any selected range.
2. Query audio utilities capability (`/api/audio/utilities/capabilities`) and `extract_mp3` supported readiness.
3. Create job through existing `/api/audio/{workspaceId}/utilities/jobs` contract with the same validation as Media Prep.
4. Persist Director task/native job link; surface selected video and a real progress card in right pane.
5. Poll/stream native job until verified registered output; show playable asset chip and actual source ID.
6. Return result to same conversation/session and offer supported follow-on edit only when user asks.
7. On failure, show concrete missing ffmpeg/asset error. On reconnection, resume status, never create second job blindly.
8. Browser test project switch while job runs: output returns to origin project, not currently visible wrong chat.

This proves actual app-wide access without implementing all 44 capability groups at once.
