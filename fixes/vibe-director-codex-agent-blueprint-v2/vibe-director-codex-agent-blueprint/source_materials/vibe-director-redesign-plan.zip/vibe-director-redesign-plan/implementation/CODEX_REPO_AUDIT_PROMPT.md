# Copy into Codex *inside the actual Vibe Director repository*

You are a senior engineer auditing and safely modernizing an existing video production application named **Vibe Director**. Before editing, read the attached/available planning pack:

- `full_review.md` (source-grounded review dated 2026-11-05)
- `tool_glossary.zip` (44 capability domains; not yet universal function tools)
- `vibe-director-six-skills.zip` (six `SKILL.md` creative skills)
- `MASTER_FIX_PLAN.md`, `design/CODEX_WORKSPACE_UX.md`, `implementation/DIRECTOR_RUNTIME_CONTRACT.md`, `implementation/IMPLEMENTATION_BACKLOG.md` (new architecture specification)

**Do not assume these docs are installed runtime features.** Validate all claims against the actual current checkout, including uncommitted changes. Do not silently discard changes. The target is a Codex-like, three-pane app (left project/tools, persistent center Director conversation, right real interactive tool/editor workspace) with flexible non-wizard workflows and six filmmaking skills loaded on demand.

### Task A — read-only source/runtime reconciliation, not a rewrite

1. Enumerate current app repository version/branch/dirty files, frontend/backend stacks, actual route/components and installed services. Exclude secrets, tokens and model weights from any report.
2. Verify these components and their contracts: `StudioShell.tsx`, `App.tsx`, `ProjectController.tsx`, `director_skills.py`, `reasoning_provider.py`, `prompt_director.py`, `StoryboardPage.tsx`, `storyboard.py`, `isolated_server.py`, `isolated_video_jobs.py`, `isolated_r2v_contract.py`, `isolated_fl2va_contract.py`, `production_job_worker.py`, `t2v_pipeline.py`, `ltx_chunks.py`, `vibe_editor_api.py`, `vibe_editor_render.py`, `media-api.ts`, `audio_utilities.py`.
3. Reconcile `tool_glossary/catalog.json` against actual implemented APIs and operation schemas; classify `callable today`, `page-only`, `adapter needed`, `backend missing`, and `runtime unavailable`. List all real current routes and TS helper signatures necessary for the first five proposed integrations.
4. Trace the Editor's current Director/chat logic: which skill/context prompt loads, what tools it can actually call, how it responds when audio extraction is requested, how project/session/media/selected range move across UI.
5. Inspect installed HyperFrames and see whether Studio components/preview or a managed local GUI can be integrated safely with existing Editor sessions, rendering and project ownership. **Do not add a dependency or launch external daemons yet.** Inspect license/runtime compatibility.
6. Audit the H3 rendering pipeline end-to-end: exact T2V/R2V/FFLF contracts; prompt Unicode length `< 7000`; R2V audio/image/video roles; whether a previous last-frame reference is a true first-frame control; how LTX jobs are prepared, checkpointed and published; how a new original-only policy could be stored without breaking frozen v2 requests.
7. Audit story/storyboard/manual automation authority restrictions and project Save/Load, pending attempts/reconciliation and cross-project isolation. Identify creative gates to relax **without touching** safety/data protections.
8. Inspect current tests, expected performance, and any live runtime readiness without running GPU generation or model downloads. Report unknowns.

### Output from Task A

Create `docs/redesign/REPO_REALITY_CHECK.md` with:
- concise `verified / outdated / unknown` table comparing supplied review to the checkout;
- exact file/line anchors and typed endpoint/adapter candidates;
- current state diagram and target delta;
- proposed minimal PR slicing in dependency order;
- explicit migration/rollback and regression tests;
- security/auth/AGPL license/HyperFrames version questions;
- blocker list with questions that need human answers.

Then create `docs/redesign/IMPLEMENTATION_PR_CHECKLIST.md` with first three low-risk PRs:

- PR1: read-only tool catalogue + readiness operations + tests.
- PR2: three-pane shell and typed right-pane navigation, persistent chat context; no engine behavior changes.
- PR3: first real tool adapter (`Extract MP3`) from Editor chat, existing media utility and asset result, with job status tests.

For each PR include exact files, schema, owner/project safety, expected tests, and manual verification steps. Recommend source-backed changes instead of generic ideas.

### Execution constraints

- **Do not modify the application as part of this read-only audit.** Do not launch real GPU/provider generations, reformat many files, rewrite job DB, delete media, alter clocks, disable watchdogs, install arbitrary external apps or introduce silent data migrations.
- Never add unknown fields to strict video generation request schemas. Never misrepresent voice identity samples as final spoken dialogue files.
- Do not replace Vibe Editor, strict screenplay assembly, or H3/LTX adapters wholesale. First prove the current working path and wrap it.
- Preserve all project IDs/assets/ledger jobs, hashes, idempotency/recovery and accepted history. Do not override the user's output folder or run unsafe shell content.
- Only after human review/approval of `REPO_REALITY_CHECK.md`, implement PR1 with focused tests. Do not combine all milestones into one change.

### Optional additional input to request from owner only if actually required

Exact active source checkout (not just the tool glossary), short list of working/broken UI paths, sample anonymized generation request/response, installed node schema, actual node/workflow versions, one backup project with media aliases only (never private credentials). Ask precise questions only when the code cannot answer them.
