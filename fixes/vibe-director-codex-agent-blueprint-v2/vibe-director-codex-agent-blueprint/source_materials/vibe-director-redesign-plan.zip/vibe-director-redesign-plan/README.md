# Vibe Director — Recovery & Codex-style Redesign Pack

**Prepared:** 2026-11-05  
**Status:** Architecture/implementation plan only. No application source was edited and no real GPU, provider, editing or generation test was run.  
**Basis:** `source_materials/full_review.md` (1,403 lines), `source_materials/tool_glossary.zip` (44 capability *groups*; not 44 callable functions), and the existing six-skill starter pack. External OpenMontage/Backlot/HyperFrames documentation was reviewed for feasibility; integration and licenses remain to be confirmed in the installed versions.

## Start here

1. **[MASTER_FIX_PLAN.md](MASTER_FIX_PLAN.md)** — executive decisions, target architecture, migration, sequencing, risk, testing and effort ranges.
2. **[design/CODEX_WORKSPACE_UX.md](design/CODEX_WORKSPACE_UX.md)** — exact left/middle/right layout, comic-book storyboard, reference-first prompt composer, Director interaction scenarios.
3. **[implementation/DIRECTOR_RUNTIME_CONTRACT.md](implementation/DIRECTOR_RUNTIME_CONTRACT.md)** — skill loading, real tool call adapters, project/event persistence, permissions, model-specific reference rules and LTX off.
4. **[implementation/IMPLEMENTATION_BACKLOG.md](implementation/IMPLEMENTATION_BACKLOG.md)** — sequenced tickets, source seams, tests and acceptance.
5. **[implementation/CODEX_REPO_AUDIT_PROMPT.md](implementation/CODEX_REPO_AUDIT_PROMPT.md)** — ready-to-paste instruction for an in-repository coding agent to verify the audit against the actual source and prepare a safe change plan.
6. **[implementation/THIRD_PARTY_DECISIONS.md](implementation/THIRD_PARTY_DECISIONS.md)** — OpenMontage, Backlot and HyperFrames options, restrictions and licensing.
7. **[source_materials/](source_materials/)** — original documents/skills preserved unmodified.

## Non-negotiable principles

- Creative stages are optional, skippable and revisit-able. Actual input dependency and runtime safety checks remain.
- One active project context and shared production data, not six incompatible pseudo-projects.
- The middle Director chat can invoke **validated backend actions** and navigate an interactive right-pane surface; skills alone are not tools.
- Manual T2V/R2V/FFLF creation does not require an accepted screenplay.
- Original assets, submitted requests, job IDs, hashes, accepted take history and GPU safety survive refactoring.
- Backlot is not the editable storyboard; HyperFrames editor integration is separately evaluated.
- Never assert that a reference image is a hard first-frame lock in an R2V contract unless the selected engine actually supports that control.

## Current evidence boundary

The supplied ZIP is a **tool glossary**, not the app source checkout. Code file references and current behavior are derived from the supplied review and glossary. A repository-backed audit and targeted tests must precede edits. This plan avoids inventing executable routes or guaranteed integrations.

## Quick visual review

Open **[design/THREE_PANE_CONCEPT.html](design/THREE_PANE_CONCEPT.html)** in a browser to switch among a conceptual Prompt, Comic Storyboard and Editor right pane while the middle Director chat remains visible. This mock is not connected to a model or backend.

## Suggested first implementation PRs

1. Read-only tool registry/capability awareness.
2. Resizable three-pane shell + project-scoped persistent chat + right-pane navigation.
3. Editor chat → existing Media Prep Extract MP3 → native job status → playable result.

Do not add LTX bypass, mixed-media automation or external repository embedding before their appropriate versioned worker/service designs and regressions.
