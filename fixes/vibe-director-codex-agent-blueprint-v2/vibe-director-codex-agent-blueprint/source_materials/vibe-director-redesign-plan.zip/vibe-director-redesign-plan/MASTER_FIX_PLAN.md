# Vibe Director — Master Architecture, UX & Repair Plan

## 0. Executive decision

**Preserve the engines; replace the fragmented experience and missing coordination layer.** The reviewed implementation already has valuable services for project persistence, asset discovery, story/screenplay, Z-Image/Qwen, MiniMax H3, R2V and FFLF, durable GPU jobs, LTX, audio utilities, and a HyperFrames-backed Editor. These services do not yet behave as one coherent production workspace. This is supported by the supplied `full_review.md` §§1, 7–9, 15–17, 21–27.

Target = a **Codex-like three-pane desktop/web app** backed by a project-aware Director orchestrator that knows **what tools exist, which are available now, how to call them safely and how to put their results on the right-hand surface**. The Director loads six creative skills on demand; it does not reinvent each generator.

## 1. Keep, adapt, replace

| Area | Decision | Rationale |
|---|---|---|
| Durable production ledger, job workers, idempotency, hash/provenance, GPU guard | **KEEP** | Protects money, media and recovery. Do not migrate frozen submitted jobs or bypass worker reconciliation. |
| Project folder/checkpoint/media library | **KEEP + present coherently** | One selected project ID and clearly described Save vs live working state. |
| Existing T2V/R2V/FFLF graph adapters | **KEEP + versioned model profiles** | Preserve exact route contracts; bring limits and reference semantics into UI/prompt skill. |
| Z-Image/Qwen image services, Media Prep audio, semantic search | **KEEP + expose typed Director actions** | Already implemented in source audit; currently not universally callable. |
| Story graph / screenplay / shot prompts | **KEEP + make advisory for manual creation** | Reuse real data and provenance, remove user-facing wizard authority. |
| Storyboard preparation and export | **REWORK PRESENTATION and backend runner** | Editable comic pages with images and dialogue; optional, selectively regenerable, resumable without browser loop. |
| Editor / HyperFrames adapter | **KEEP; improve right-pane UI and handoff** | Existing validated renderer already works with project-owned media; investigate Studio embedding separately. |
| Strict screenplay assembly | **KEEP as strict export option** | Add a separate flexible edit/timeline path for mixed image, clips and existing footage. Do not pretend accepted-take assembly is freeform. |
| Multiple disconnected Directors and authority switches | **CONSOLIDATE coordinator + thin adapters** | One chat surface; specialist skills and service-owned validations still apply. |
| Full auto image-free-only default | **REPLACE policy for new runs** | A unified task graph must permit mixed stills, R2V, T2V, existing footage; migrate via new manifest version only. |
| LTX always-on postprocessing | **ADD explicit quality path** | Must be truly disable-able for new runs; preserve old job behavior. |
| OpenMontage/Backlot | **OPTIONAL integration** | Valuable knowledge/research and living-board ideas, but external data model, security and license need review. |

## 2. System architecture

```text
┌───────────────────────────────────────────────────────────────────────────────┐
│ Project switcher + job/activity rail                                         │
├───────────────┬──────────────────────────────┬────────────────────────────────┤
│ LEFT          │ MIDDLE                       │ RIGHT                          │
│ Projects      │ Persistent Director chat     │ Real interactive work surface  │
│ Navigation    │ Attach / discuss / approve   │ Screenplay, prompts, images,   │
│ Asset library │ Skill-aware tool calls       │ storyboard, Video, Media Prep, │
│ Runs / jobs   │ Plan and job progress        │ timeline / HyperFrames, jobs   │
└───────────────┴──────────────┬───────────────┴────────────────────────────────┘
                               │
                    Director Orchestrator
                  (project scoped + persisted)
                     │       │        │
             Skill router  Tool registry  UI navigation bridge
                 │              │
      six creative SKILL.md   validated tool adapters
                                │
                    existing app services / APIs
             story | media | images | audio | video | editor
                                │
                 durable jobs + assets + project checkpoint
```

**Important:** The chat and right-pane pages invoke the **same backend contracts**. A click and a chat tool call cannot become competing implementations. The shell should render existing React components where possible; it must not iframe internal pages and fake interaction.

## 3. One shared creative project model

Introduce a **Production Document** (revisioned project-scoped planning model), *initially an adapter/projection* over existing stories, scenes, shots, media and job data. Avoid a giant destructive database migration.

Minimal records (names provisional):

```text
ProjectContext: projectId, folder, activeConversationId, selectedPage,
                selectedAssets[], editorSessionId?, outputDestination
ProductionDocument: documentId, revision, sourceStoryId?, screenplayRevisionId?,
                    title, scenes[], timelineEntries[], creativeStatus
Scene: sceneId, slugline?, summary, locationId?, orderedShotIds[]
Shot: shotId, sceneId, action, dialogue[], camera, mood, durationEstimate,
      boardPanelIds[], intendedContinuity
Panel: panelId, shotId, clipGroupId?, timeRange, imageAssetId?, imagePrompt,
       action, dialogue[], referenceAssetIds[]
ClipDraft: clipId, shotIds[], modelProfileId, route, prompt, duration,
           referenceBindings[], openingPolicy, endFramePolicy, renderPolicy
Take: existing immutable job/request/output references (do not duplicate)
TimelineEntry: id, kind=image_hold|existing_video|generated_take|audio,
               sourceAssetId, in/out, timelineStart, duration, transition,
               audioOptions
DirectorTask: id, conversationId, projectId, steps[], jobIds[], status
```

The *same* `ClipDraft` can come from a storyboard panel, screenplay, an existing video or manual entry. Its origin is optional provenance, **not permission to generate**. An imported video can enter the editor without any story. Existing accepted screenplay/take coverage stays available as the **strict assembly** route. The freeform `TimelineEntry[]` path is a separate flexible composition input until backend convergence is verified.

## 4. Skills — one Director, six specializations

Keep the six supplied skills as **creative policy**, not server-side permissions:

| Trigger from chat or page | Skill(s) | Existing capability families |
|---|---|---|
| “Write a film from this story” | `screenplay-writer` | `story.author`, `story.graph` when useful, `story.screenplay` |
| “Make the lion character” | `character-designer` | `images.generate`, `images.production` (Z-Image), `media.browse` |
| “Create the forest/background” | `environment-designer` | `images.generate`, `images.production` |
| “Turn the whole story into a fast comic” | `storyboard-director`, `continuity-director` | `story.board`, `images.generate`, `images.production` |
| “Give me the next H3 prompt and refs” | `cinematic-prompt-director`, `continuity-director` | `video.r2v/t2v/fflf`, `video.review`, `media.browse` |
| “Keep this look across the next clips” | `continuity-director` | project assets, production takes, continuity frame extraction |
| “Extract audio / make an edit” | tool catalogue, Editor specialist rules | `audio.extract`, `editor.edit`, `editor.export` |

Skills should load **on demand** along with *one* relevant tool-domain guide and live capabilities, not stuff every `SKILL.md` and 44-group glossary into every model prompt. A product-level task router resolves intent and selected context. Editor specialist instructions must no longer assert that tools such as MP3 extraction are unavailable merely because the Editor renderer cannot do them (`full_review.md` §27.1).

## 5. Design the core surfaces

### A. Story and screenplay
- Story can be typed, imported, revised or skipped.
- Screenplay shows scenes, plot, dialogue, intended running time and optional shot/clip breakdown.
- Chat can propose changes and apply them with version/conflict checks.
- Model length constraints apply **when allocating generation clips**, not when writing story scenes.

### B. Characters, voices and worlds
- Character Master card: canonical identity, approved image(s), views/expression options, selected voice identity sample, model/style.
- Z-Image prompt writer includes shape, expression, costume, fixed color/markings, composition, plain background as appropriate, exclusions. Stable identity metadata is stored separately from image prompt.
- Location Bible: world identity, lighting, palette, landmarks, spatial layout and multiple views.
- Do not make image creation mandatory for T2V or use filenames as identity authority.

### C. Editable comic-book storyboard
- One visual **panel per beat/shot** with dialogue/action/timing in **UI outside AI image**; typically 3–6 panels per 15s clip, but not required.
- Group panels under a `clipGroupId` and mark `one_continuous_shot` vs intentional cut.
- Panels reorder/edit/regenerate **individually**. A generated storyboard is not automatically a video generation.
- Scene pages, contact sheets, approval markers, image candidates, and optional print/HTML export. Keep existing board data and export route where possible.
- Prepare images using approved character/location refs; browser closing should not stop a backend-owned generation sequence.

### D. Video Prompt Composer — reference-first
The prompt UI must look like the prompts the user approved in conversation:

1. **Reference manifest first** (exact slots with asset thumbnails, stable asset IDs, usage notes, ready/missing status).
2. Route/model profile, duration, aspect, LTX quality toggle and estimated cost/resource class.
3. Visual timeline of **timecoded action and camera beats** (e.g. 0–2, 2–6, 6–9, 9–12, 12–15 seconds).
4. Timed dialogue lines mapped to **voice identity samples**, not asserted to be already recorded speech.
5. Soundscape, music policy, hard constraints and designed ending frame.
6. Final model-specific prompt with code-point count, timeline validation, reference-token validation and **Edit / Copy / Generate**.

For current H3 R2V, the audit says **5–15 s**, at most **9 images / 3 videos / 3 audio**, prompt **strictly below 7,000 Unicode code points** (i.e. 6,999 max); T2V is a separate 5–30 s engine contract and FFLF requires **both** first and last frame assets. Model profiles, not one global constant, govern new routes (`full_review.md` §11). The owner's standard creative target is 15 seconds for H3 clips.

**Critical honesty of reference semantics:** R2V can receive a previous clip's extracted final frame as an **image reference and opening-composition instruction**, but the current reviewed R2V schema does *not* have a dedicated `first_frame` field. It must **not** be described as a guaranteed first-frame pixel lock. A true first/last-frame endpoint is the separate FFLF route and requires both images. This distinction matters for reproducibility.

### E. Media Prep and quick utilities
- Add `Extract first frame`, `Extract last frame`, optional `Extract frame at timecode`, accessible from clip player, library card, Director chat and next-clip prompt composer.
- Prefer the existing `POST /api/video/jobs/{id}/continuity-frame` for eligible generated takes; general imported clips may need a new media utility adapter. FFmpeg extraction + media registration + hash/version identity + source provenance.
- Reuse existing `audio.extract` → Extract MP3 service; do not duplicate it (`full_review.md` §27.1).

### F. Editor / finish
- Main path = select media, describe edit in chat, see a **real** timeline and preview on right, approve a render as needed, export.
- Keep Vibe Editor's two existing brief/plan approvals until redesigned intentionally; avoid hidden repeated approvals in ordinary tasks.
- Add a **Quick Assemble** mode from freeform `TimelineEntry[]` with video, image holds, and audio; send complex/custom motion work to HyperFrames-backed Editor.
- Preserve strict accepted-take screenplay assembly as an optional reproducible finishing path, not the only export path.

## 6. Director's tool bridge: the missing engine

`tool_glossary.zip` describes **44 capability groups**, not 44 callable functions. Implement concrete typed operations under them (e.g. `media.asset.find`, `audio.extract_mp3.start`, `audio.job.get`, `video.continuity_frame.create`, `editor.plan.propose`, `editor.render.start`). Every operation must declare:
- input/output JSON schema and project/session context;
- capability/readiness check, selected asset identity/role and time-range semantics;
- side-effect/cost level, authorization policy;
- service adapter and deep-link/navigation target;
- job create/status/recovery/cancel abilities only where existing service supports them;
- verified result asset ID and downstream handoff.

Implement the **first complete vertical slice**: user attaches video in Editor chat → Director selects existing Extract MP3 → runs supported job with durable ID → right pane opens Audio Utilities and shows progress → extracted audio asset is playable in Editor chat → preserve source and project. This establishes the architecture before broadening to 44 groups. `full_review.md` §27.6 proposes this same anchor test.

## 7. Fix the creative locks without removing safety

Define an explicit **Blocker Report** containing `category`, `humanReason`, `affectedAction`, `jobId?`, `canRecover`, `nextAction`:
- creative recommendation only: **never blocks manual creation**;
- invalid draft input: fix/edit field;
- capability/node mismatch: show missing dependency;
- pending uncertain attempt: reconcile/release with existing fence mechanism;
- active GPU job/thermal safety: show status, don't bypass;
- stale strict automation plan: fork/replan, preserve frozen take;
- editor brief/plan approval: show what needs approval and why;
- project checkpoint busy: show owning task instead of generic lock.

Don't remove idempotency keys, asset hash ownership verification, frozen-job snapshots, or existing output collision checks (`full_review.md` §§12, 19).

## 8. LTX Upscaling OFF — a real end-to-end mode

This is a **backend/worker + contract change**, not a checkbox that only changes UI:

- User-visible policy: `Original (H3 Turbo / no LTX)` vs `Refined (H3 + LTX)`, defaults explicitly chosen in settings.
- The policy is captured **when Generate is admitted**, frozen for each job (and retakes, batches, assisted/auto runs). Do not silently change jobs already queued/running.
- Current exact-field video request contracts must not receive an invented extra field. Implement via a **versioned job envelope/render policy** or a **new schema/workflow version**, after source trace and tests.
- With LTX OFF: skip LTX planning, windows, chunk jobs and final LTX stitching entirely. Collect original H3 output, trim/normalize to the requested duration, verify audio/video streams, register and publish a `Turbo Original` final artifact with correct quality dimensions and provenance.
- With LTX ON: retain current durable refinement/checkpoints and verified enhanced output behavior.
- Do not silently publish a Turbo original as if it were enhanced when LTX fails; offer an explicit reviewed fallback if product policy allows it.
- Capability UI must separate `Turbo ready` from `LTX ready`; Original mode should not be blocked by a refinement-only issue when the Turbo route itself is safe.
- Regression: T2V, R2V, FFLF, manual/retake/batch/automated policy where supported; audio/time/fps preserved; restart/reconcile and no unnecessary GPU job on OFF.

## 9. One optional-stage task graph, not one forced sequence

Every creative operation is independently callable **if its actual inputs exist**. A project may begin with a clip, character, prompt, or story. Planning stages are available as *recommendations*.

```text
story? ──> screenplay? ──> comic board? ──> selected images?
  │             │                   │
  └─────────────┴───────────────────┼──> clip drafts ──> job takes
existing video/image/audio ────────┘                     │
                                                         v
                                        freeform edit/timeline or strict assembly
                                                         │
                                                         v
                                                    verified export
```

Automation uses server-persisted **dependencies**: e.g. R2V requires selected real references; T2V does not require characters; Editor needs media; a true FFLF requires two frames. Manual/assisted/automatic set *who approves each operation*, not which unrelated creative steps the user must visit. Use a new run-manifest version for mixed-media; keep older manifests and their recovery logic stable.

## 10. External projects: cautious integration

- **HyperFrames**: strongest near-term integration; existing Vibe Editor already renders through it. Test current installed adapter first, then optionally expose the HyperFrames Studio preview/timeline in the right pane via supported React entrypoints or a managed localhost GUI. Bridge selected media, edits and outputs through validated project APIs; do not let an external GUI become an untracked shadow project.
- **OpenMontage**: borrow portable skill/pipeline ideas and consider a **separate optional adapter** for research, footage retrieval and documentary montage. It uses different project/checkpoint conventions and license obligations. Do **not** replace H3/ComfyUI, existing production ledger, or unify storage by copying repositories wholesale.
- **Backlot** (OpenMontage): a **read-only local living board** of checkpoints/asset progress, not an editable storyboard or editor. Use its design as inspiration for an app-native run board based on the Vibe Director ledger; optionally add an external board view only with tested localhost access and project translation.

See `implementation/THIRD_PARTY_DECISIONS.md` for licensing/runtime details and evidence.

## 11. Implementation order and rough effort

These are **engineering-effort planning ranges**, not a delivery promise; review must be reconciled with the actual source checkout and runtime before staffing/scheduling:

| Gate | Work | Approx. engineering effort | Exit criterion |
|---|---|---:|---|
| P0 — freeze & inventory | Reproduce baseline, backup project, map schemas/tools/tests, document critical operations | 3–5 engineer-days | No data loss; inventory tagged available/unverified/gap |
| P1 — workspace shell | Resizable 3 panes, persistent chat context, right-pane routing, project isolation | 7–12 days | Navigation retains chat/assets/unsaved state |
| P2 — tool kernel | Typed registry, read/status APIs, Extract MP3 vertical slice, durable tool task loop | 8–15 days | Chat actually extracts and returns playable asset |
| P3 — creative UX | Model profiles, prompt/reference composer, Z-Image briefs, six-skill routing | 7–12 days | Timed ≤15s R2V with valid refs and <7000 chars |
| P4 — comic board | Editable panels, batch images, reuse and backend-owned resume, handoffs | 8–14 days | Fast full-story board + selective regenerate |
| P5 — engine and sequencing | LTX-off path, continuity frames, mixed-media task/production document, blocker reporting | 12–22 days | Original-only output; flexible routes; no broken jobs |
| P6 — finishing | Real Editor pane, flexible timeline, HyperFrames Studio proof-of-concept, export | 8–15 days | Chat-to-editor render with tracked media |
| P7 — hardening | project migration/resume, cross-project isolation, E2E regression, real runtime acceptance | 8–15 days | Critical acceptance scenarios pass |
| Optional | OpenMontage/Backlot external bridge | separately scoped | License-reviewed adapter and proven isolated exchange |

A useful **first slice** is P0–P2, not the entire redesign. Some items can proceed in parallel, but the registry/project/context foundation should precede wide automation. Avoid calendar commitments without actual checkout, staffing and runtime evidence.

## 12. Migration and rollback

1. Tag/backup current source plus a real project folder, `vibe-project.json`, ledger and media/library records; do not invent project paths.
2. Add new tables/document projections behind feature flags (`director_shell_v2`, `tool_bridge_v1`, `mixed_timeline_v1`, `h3_turbo_final_v1`).
3. Preserve old project snapshots and versioned production manifests. New drafts can be projected from legacy screenplay/board data; old jobs remain immutable.
4. Migrate by **copying/reading** metadata into new records, never rewriting submitted job payloads or media hashes. Provide compare/audit output.
5. Roll out to one test project; can revert UI flag while old services continue to function.
6. Keep `Legacy editor/assembly` as optional access until new paths meet media/quality parity.

## 13. Acceptance tests grounded in the user's workflow

1. **No screenplay:** create R2V from 2 character images + optional audio voice sample; prompt/ref order/duration validate; successful take appears in project.
2. **Continue clip:** extract last frame as a registered asset; bind in next clip image slot; UI clearly identifies *opening reference* vs hard FFLF first-frame route.
3. **Voice identity:** mouse/lion WAVs bind to proper speakers; do not treat them as prerecorded words or silently add voices to no-dialogue clip.
4. **Prompt lint:** e.g. 6,999 code points accepted; 7,000 rejected if backend is strictly `<7000`; 16s rejected for R2V, 15s accepted if nodes ready.
5. **LTX off:** no refine jobs; verified Turbo original video/audio published as labeled output; preserves timing; refinements still work when ON.
6. **Director audio request:** Editor-attached video → Extract MP3 (actual existing utility) → playable result in same chat/project; user can open tool without losing conversation.
7. **Storyboard:** comic panels with images, spoken lines and times; regenerate one panel without discarding others; no forced screenplay acceptance.
8. **Editor:** select/generated clips and image holds, arrange in timeline, render through supported HyperFrames path, receive verified file.
9. **Recovery:** lost response does not double-submit GPU job; pending-state lookup/release gives actionable result; frozen prior take survives retake.
10. **Project switch:** working in projects A and B never swaps voice, chat, references, job outputs or media owners.
11. **Blocked action:** missing node, GPU hold or unready engine shows exact blocker and available next action, not disabled-all mystery.
12. **Optional automatic flow:** mixed image/R2V/T2V/still plan runs with explicit decisions and backend-owned checkpoint, resumes after browser restart.

## 14. Source seams to investigate before editing

From `full_review.md` source map: `StudioShell.tsx`, `App.tsx`, `ProjectController.tsx`, `storyboard.py`, `StoryboardPage.tsx`, `prompt_director.py`, `director_skills.py`, `isolated_server.py`, `production_setup.py`, `fully_automated_clip_plan.py`, `isolated_video_jobs.py`, `isolated_*_contract.py`, `production_ledger.py`, `production_job_worker.py`, `t2v_pipeline.py`, `ltx_chunks.py`, `vibe_editor_api.py`, `vibe_editor_render.py`, `media_library.py`, `media_discovery.py`, `audio_utilities.py`.

**What is NOT in this package:** the actual app repository/source ZIP, GPU object-info schema, installed node graph versions, or a fresh live runtime acceptance result. `implementation/CODEX_REPO_AUDIT_PROMPT.md` requests the narrow information needed to move from architecture to safe code changes.
