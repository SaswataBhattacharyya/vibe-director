# Source archive checksums

Original uploaded sources copied into this pack without edits. SHA-256 values permit integrity verification.

| Original | Pack path | SHA-256 |
|---|---|---|
| `full_review.md` | `source_materials/full_review.md` | `2649f4ab0628ca6db7df1789bed7e6987ffa30c2248f562834e32e6857a14aa7` |
| `tool_glossary.zip` | `source_materials/tool_glossary.zip` | `7b85913bbaf5f42c80cb5ad4645317095e9ef9a1aa852b5394eaaaeb06cab016` |
| `vibe-director-six-skills.zip` | `source_materials/vibe-director-six-skills.zip` | `8aeff2c4f53a9eb0451a84068170343c5512bbb53d30d8d76d7d32b8f5d75603` |
