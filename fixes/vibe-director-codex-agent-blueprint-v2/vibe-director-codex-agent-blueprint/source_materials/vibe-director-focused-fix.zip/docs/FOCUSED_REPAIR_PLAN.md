# Vibe Director — Focused Production-Side Repair Plan

Version: 2026-11-05; based on the supplied `full_review.md`, `tool_glossary.zip`, screenshots and conversation. This is a **design and implementation plan, not a code patch or a runtime test**. Verify files/contracts against the actual checkout before changing them.

## 1. Decisions that override the broader redesign

1. **Keep the LEFT navigation as it is.** Preserve existing project chooser, route labels and access to standalone tools. Allow a compact/collapsible mode but don't redesign it in phase 1.
2. **Keep Media Prep as it is.** Its page, utilities and standalone workflows already satisfy the owner. Do not rewrite or relocate media logic. Add a thin shared Director/Editor adapter around existing API endpoints so a chatbot can use the functions.
3. **Fix the VIDEO-PRODUCTION side:** Production Type & Style, Story, Screenplay, Characters & Voices, Worlds, Frame per Shot, Storyboard, Prompt Preparation, Video Create/Current Take and their connections.
4. **One persistent Director chat.** In the film-production surfaces the chat stays at center; a real existing application page stays interactive at right. Vibe Editor shares this tool gateway and keeps editor-specific knowledge. Avoid simultaneous, conflicting chat histories.
5. **No enforced wizard.** Every page is a valid entry point. Choosing production style, writing a screenplay, making a storyboard or accepting a plan are optional unless the user explicitly chooses a strict automated workflow that requires lineage.
6. **Skills are instructions, tools are executions.** Seven skills (the earlier six plus Production Style Director) guide outputs; real typed app API adapters read/save/generate/edit/extract.
7. **Preserve ledgers, GPU guard, asset IDs/hashes, immutable requests and recovery.** Never delete existing runs to simplify navigation.

## 2. Target experience

```text
TOP: Project  | Save/Load | Current job state                   (existing)
LEFT (KEEP)   | CENTER (ADDED / persistent)   | RIGHT (existing workspaces)
Navigation    | Director / Editor chat        | Production Brief (formerly Type & Style)
Media Prep    | selected assets + context     | Story / Screenplay / Comic Board
Video/Create | tool call cards and progress  | Characters / Worlds / Prompt Studio
Vibe Editor  | feedback, accept/revise       | Video Create / Current Take / Editor
              |                              | Actual previews and editable controls
```

At narrower widths, center conversation can collapse to a drawer or overlay, returning width to the right workspace. Do not hide the actual page behind a fake static preview. Existing left nav does not need replacement.

## 3. Production Type & Style becomes an optional Creative Brief

Current production type/style selection is versioned and can affect downstream planning. Reuse those records; do not invent a new hard gate. Refactor `ProductionStylesPage.tsx` to make guidance, not a mandatory first step:

**Independent selectors**
- **Production TYPE:** Short film / feature film / animated fable / advertisement / documentary / educational / corporate / music video / custom. Determines screenplay conventions and story goals.
- **VISUAL STYLE:** Cinematic realism / Anime / Stylized 3D / Watercolor / Comic / Stop-motion / custom. Determines appearances of character, location and board images and video look. A 'film' can be 'anime'; a 'short film' can be '3D stylized'.
- **DIRECTING LANGUAGE:** Cinematic camera, handheld observational, static tableaux, fast-cut, slow poetic, custom. Describes camera, lighting and pacing, can be used with any visual style.

**UI:** three small selectors (or cards), 1–3 sentence generated guideline preview, optional advanced controls, `Use for Project`, `Use for this Scene/Shot`, and `Skip for now`. User can type “make a 3D anime short film with cinematic camera” in chat and see the form populated. Keep previous pinned style versions for already-admitted work. Do NOT require style approval to do manual Video Create.

**Skill:** `production-style-director`. Load it for style/type requests and with downstream skills only when actual style guidance is relevant. A skill does not replace the versioned production style records; it tells the Director how to interpret and apply them.

## 4. Screenplay and storyboard — simplify the creative workflow

**Screenplay:** Show scenes, location, action, dialogue with speakers, scene estimate and optional shots. Chat can “shorten dialogue”, “make this anime”, “split into 15-second clips”, “make the lion less aggressive”, propose and apply versioned edits. Keep evidence/graph for projects that use it; do not require graph or accepted screenplay to make a video from an independent prompt.

**Storyboard:** A fast **comic-book overview** of the entire story. One panel = one visual beat, not necessarily one generated video clip. Each panel has an image, action, character dialogue, camera note and duration. Split panels into optional 5–15-second clip groups for R2V or FFLF. Generate panels with Z-Image/Qwen using approved character and world references; allow quick full-board drafts, single-panel retake and manual image replacement. Keep dialogue/text outside the generated art. Reuse `storyboard.py` and the existing HTML export path, then improve board preparation job durability.

**Prompt Preparation:** Rename presentation to **Prompt Studio** (route can remain `#/prompts`). Use the established format: reference manifest FIRST, instructions for each selected asset, mode/duration settings, timed beat table, final validated prompt, ending/continuity note. Allow chat revisions without overwriting user's raw prompt or order. Selected refs are stable asset IDs; `<Picture 1>`, `<audio1>` labels are derived from current input order. Model limits and allowed combinations come from backend capability, not only skill prose.

## 5. Video generation: route semantics must be truthful

Reviewed local contracts: T2V 5–30s, FL2VA/FFLF 5–15s (requires BOTH first and last frames), R2V 5–15s (up to 9 image, 3 video, 3 audio refs; role/intent fields), and prompts strictly below 7,000 Unicode codepoints.

**Do not present an R2V image named 'First frame' as guaranteed first-frame conditioning.** If the model/mode supports a true first-frame input, bind to that actual field. The reviewed standalone FFLF contract needs both first and last images. If user wants image characters + exact first frame and that combination is unsupported, say so and propose a supported route or create a deliberate first frame with image tools.

On each video draft show:
1. Selected generator and valid route, duration/aspect.
2. References table: slot / asset thumbnail / role / `intent` / voice identity vs prerecorded audio / validation status.
3. `[00:00–00:03]` etc timed events; camera, physical behavior, sounds and exact voice-mapped dialogue.
4. 'Generate' executes existing validated API, returns a durable job ID; Current Take shows real state. A missing screenplay should not lock this route.
5. 'Extract end frame' from a verified clip, register as an asset and offer to attach to **next draft**. Reviewed existing endpoint `/api/video/jobs/{id}/continuity-frame` is a candidate; confirm actual payload/outputs.
6. **LTX on/off** is real execution policy for NEW jobs, not just a UI flag. Requires versioned backend envelope and worker changes; original-only mode still probes, trims, preserves generated audio and publishes correct provenance. Existing LTX-enhanced frozen jobs must remain unaffected.

## 6. One Director/Editor tool gateway

Create a shared **typed capability registry** backed by the actual services in the glossary, with live readiness and ownership enforcement. Start small; the 44 glossary domains are selection groups, not 44 runnable tools. Each executable operation should expose `id`, `input_schema`, `output_schema`, `capability`, `invoke`/`status`, `required context`, `job lifecycle`, `UI target`, and `side effect`.

**Example actual operations to wrap (names are proposed, validate first):**
- `project.current`, `media.catalogue.search`, `media.asset.preview`
- `story.read`, `screenplay.propose_edit`, `screenplay.apply_edit`
- `image.prompt.prepare`, `image.generate`
- `storyboard.read`, `storyboard.panel.prepare`, `storyboard.panel.save`
- `video.continuity_frame`, `video.validate_draft`, `video.create_job`, `video.job.status`
- `audio.extract_mp3` → reuse Media Prep `/api/audio/{workspace}/utilities/jobs`, not duplicate processing
- `editor.session.open`, `editor.plan.propose`, `editor.render` (respect existing approval contracts)
- `ui.open_surface` (navigate right pane with selected media, session, frame/time range)

Director chat and Editor chat use **the same gateway** and project-scoped asset/action context; specialized prompts determine editing expertise. On request, show action cards “Use last frame” / “Prepare storyboard” / “Open in Vibe Editor” with real operations and intermediate results. Never let the model call arbitrary shell/HTTP from user-facing chat. Preserve renderer limitations; route to other app tools if a capability exists there.

**First full test:** In Editor, user requests “Extract MP3 from this video”, Director calls the existing Media Prep utility, tracks the job, returns registered audio and opens the corresponding UI. Original Media Prep stays unchanged.

**Second full test:** User asks “Continue lion/mouse with a 15s prompt”, Director resolves existing references, reads last take, suggests last-frame extraction where appropriate, compiles timed prompt <7000, populates Video Create without a screenplay requirement, validates route, and only submits a render when asked.

## 7. Task order & file touchpoints

**Phase 0 — Freeze what's already good**
- Capture regression checks for left nav, project Save/Load, Media Prep audio/image utilities, video manual Create and Editor operations; record supported backend versions. Add feature flags for new UI. Do not change Media Prep code without a demonstrated bug.

**Phase 1 — Creative Brief**
- Inspect `frontend/src/ProductionStylesPage.tsx`; `backend/story_builder/services/production_styles.py`, `prompt_styles.py`. Implement independent type/style/direction fields through a backward-compatible versioned adapter. Keep old style IDs readable. Wire `production-style-director` into actual skill loader in `director_skills.py`.

**Phase 2 — persistent chat and shared tool gateway**
- Inspect `StudioShell.tsx`, `ProjectController.tsx`, `VibeEditorPage.tsx`, `EditorWorkspace.tsx`, `director_skills.py`, `reasoning_provider.py`, `vibe_editor_api.py`. Add project-scoped persistent conversation and right-pane surface selection **without rebuilding left nav**. Build typed registry, one safe action adapter and tool progress cards. Start with Media Prep MP3 extraction. Keep Editor approval semantics.

**Phase 3 — screenplay, story and comic storyboard**
- Inspect `StoryPage.tsx`, `ScreenplayPage.tsx`, `ScreenplayDirector.tsx`, `StoryboardPage.tsx`, `storyboard.py`, `story_authoring.py` and image job services. Add chat-assisted edits, comic board layouts and selectable panel-to-video grouping; move optional auto-frame orchestration from browser loop to durable backend tasks.

**Phase 4 — Prompt Studio and reference-aware Video Create**
- Inspect `PromptPreparationPage.tsx`, `PromptDirector.tsx`, `App.tsx`, `video-api.ts`, mode contract validators and `prompt_director.py`. Implement manifest+timeline prompt editor, output/codepoint linter and truthful route handling, direct handoff to Video Create.

**Phase 5 — utilities and LTX OFF**
- Reuse existing end-frame/continuity endpoint. Add true original-only verified finishing path with versioned request policy and tests. Preserve enhanced path and old jobs. Introduce one merged blocker report instead of ambiguous “ready” labels.

**Phase 6 — Vibe Editor and optional ecosystem**
- Adapt existing HyperFrames right-pane editor, with shared chat/gateway and session context. Consider embedded HyperFrames Studio only after a working roundtrip PoC. Keep OpenMontage and Backlot OPTIONAL until license, data model and runtime integration are checked.

**Phase 7 — integration & acceptance**
- Test entry from ANY page (no story, imported video, existing character, standalone asset, screenplay, storyboard, Editor). Confirm project isolation, idempotency, source-media safety, prompt/refs validity and real rendering when authorized. Only retire old routes after parity.

## 8. Acceptance scenarios

1. User picks **Short Film + Anime + Cinematic Camera**; receives suitable screenplay guidance and Z-Image prompts, no generation locks.
2. User skips production setup and storyboard, selects lion+mouse images + voice samples, creates a valid 15s R2V prompt under 7k characters.
3. Director distinguishes exact first-frame from R2V image-reference semantics and rejects unsupported combinations BEFORE rendering.
4. Chat helps rewrite a screenplay, shows diff, and saves a new revision only when user accepts changes.
5. Full comic storyboard renders panel images and dialogue; one panel can be regenerated without losing other panels.
6. User starts in Editor, extracts audio through existing Media Prep, receives playable file, without leaving chat or rewriting Media Prep.
7. Persistent chat survives navigation and Save/Load; project A data never enters B.
8. Video job survives UI reload, retake uses existing provenance, no duplicate generation after network issues.
9. LTX OFF runs no LTX chunk jobs; published Turbo output has correct audio/duration. LTX ON old workflow still works.
10. Strict screenplay assembly remains available; flexible Editor can use image holds and existing media without fake accepted-take bindings.

## 9. What is NOT done

This plan does not inspect the user's live repo, modify app code, enable new skills in the actual runtime, change Media Prep, or verify GPU output. Request a repository ZIP or run the companion Codex prompt in the checkout. The review/glossary are static audit evidence, not current execution proof.
