# Codex prompt — first safe implementation slice for Vibe Director

You are working in the actual Vibe Director checkout. Read the supplied `full_review.md`, `tool_glossary/README.md`, `tool_glossary/INTEGRATION.md`, `FOCUSED_REPAIR_PLAN.md`, and the seven skill files before editing code. Treat those documents as goals and historical review, **not proof the current checkout is unchanged**.

GOAL: fix the video-production experience while PRESERVING the existing left navigation, project controls, Media Prep UI and backend, durable job safety, original assets, and the working Video/Editor paths.

TARGET: optional Creative Brief with independent `production_type`, `visual_style`, and `directing_language` (e.g. short film + anime + cinematic camera); persistent Codex-style Director chat alongside the existing right-hand page; shared typed tool gateway callable by both Director and Editor; no forced wizard steps. Media Prep works exactly as before.

IMPLEMENT ONLY ONE SAFE VERTICAL SLICE AT A TIME:

1. **Inventory first, do not blindly refactor.** Find exact versions of `ProductionStylesPage.tsx`, `production_styles.py`, `prompt_styles.py`, `StudioShell.tsx`, `director_skills.py`, `vibe_editor.py`, `audio_utilities.py`, and related frontend API helpers. Report existing contracts and acceptance test commands. Check current uncommitted changes; do not discard or overwrite them.
2. **Baseline tests**: run relevant existing tests; record pass/fail and protect the Media Prep and left navigation routes.
3. **Implement optional creative brief** with backward-compatible data storage/mapping. Separate type/style/direction, add skip support, show concise guidelines, and do not create a screenplay dependency on manual Video Create. Load the new `production-style-director` skill on relevant requests.
4. **Add or extend one shared UI bridge** for the persistent chat to populate and open an existing interactive work surface; do not rebuild the navigation and do not iframe internal React pages.
5. **Tool gateway proof:** expose only a small typed registered tool catalogue initially, and wire the existing `extract_mp3` Media Prep utility through a safe adapter with owner/session context, readiness, input validation, durable job status and playable returned asset. Director and Editor must use the same adapter. Leave the original Media Prep page intact.
6. **Tests and demo:** verify `Short film + Anime + Cinematic camera` in Creative Brief, style guidance reaches a screenplay or prompt draft, Editor extracts MP3 via chat, navigation works, left sidebar unchanged, and Media Prep keeps its original behavior.

Do not attempt to rewrite project saves, legacy submitted jobs, LTX engine, all 44 tool groups, or full auto production in this first change. Do not introduce a shell/HTTP-anywhere agent tool. Maintain permission/approval and provider/GPU safety gates. Show real unsupported dependencies and blockers rather than fabricated success.

When complete, report exact files changed, migrations/compatibility behavior, tests run with results, what was not tested on GPU, and the smallest next slice. If source/schema mismatches the review, explain before changing contracts.
