# Capability Rollout Matrix — all 44 glossary groups

All 44 rows are **source-inventory groups, not confirmed callable Director tools**. This table is a *proposed integration order* only. Check live readiness and exact input schemas first.

| Group | Priority | Existing UI reported by glossary | Integration goal |
|---|---|---|---|
| `project.manage` | P2 (first tool slice) | Global project bar | Typed actions + UI deep link |
| `output.destination` | P3–P5 (core creative) | Output folder controls in tools | Typed actions + UI deep link |
| `story.styles` | P4–P7 (expand) | #/styles | Typed actions + UI deep link |
| `story.author` | P3–P5 (core creative) | #/story | Typed actions + UI deep link |
| `story.graph` | P4–P7 (expand) | #/story → Story graph | Typed actions + UI deep link |
| `story.screenplay` | P3–P5 (core creative) | #/screenplay | Typed actions + UI deep link |
| `story.board` | P3–P5 (core creative) | #/shot-frames or #/storyboard | Typed actions + UI deep link |
| `production.setup` | P3–P5 (core creative) | #/setup | Typed actions + UI deep link |
| `prompts.prepare` | P3–P5 (core creative) | #/prompts | Typed actions + UI deep link |
| `images.generate` | P3–P5 (core creative) | #/text-to-image | Typed actions + UI deep link |
| `images.production` | P3–P5 (core creative) | #/characters, #/worlds, #/frames | Typed actions + UI deep link |
| `images.inspect` | P4–P7 (expand) | #/media-prep → Images → Image Detailer | Typed actions + UI deep link |
| `images.training` | Later (specialized / guard) | Training controls exposed by image tools; inspect current UI | Restricted typed actions; explicit authorization |
| `video.t2v` | P3–P5 (core creative) | #/video → Text to video | Typed actions + UI deep link |
| `video.r2v` | P3–P5 (core creative) | #/video → Reference to video | Typed actions + UI deep link |
| `video.fflf` | P3–P5 (core creative) | #/video → First + last frame | Typed actions + UI deep link |
| `video.review` | P3–P5 (core creative) | #/take | Typed actions + UI deep link |
| `video.runs` | P3–P5 (core creative) | #/setup, #/prompts and #/video production controls | Typed actions + UI deep link |
| `video.assembly` | P3–P5 (core creative) | Assembly panel in production review | Typed actions + UI deep link |
| `media.browse` | P2 (first tool slice) | #/media or media source pickers | Typed actions + UI deep link |
| `media.semantic` | P4–P7 (expand) | #/media → Search | Typed actions + UI deep link |
| `media.download` | P4–P7 (expand) | #/media-prep → Video Summariser → YouTube Download | Typed actions + UI deep link |
| `media.analyse_video` | P4–P7 (expand) | #/media-prep → Video Summariser → Analyze / Results / Audio Assets | Typed actions + UI deep link |
| `media.style_frames` | P4–P7 (expand) | #/media and style-reference controls | Typed actions + UI deep link |
| `media.delete` | Later (specialized / guard) | Search/library selection actions | Restricted typed actions; explicit authorization |
| `audio.extract` | P2 (first tool slice) | #/media-prep → Audio → Utilities → Extract MP3 | Typed actions + UI deep link |
| `audio.utilities` | P4–P7 (expand) | #/media-prep → Audio → Utilities | Typed actions + UI deep link |
| `audio.isolate` | P4–P7 (expand) | #/media-prep → Video Summariser results/audio events | Typed actions + UI deep link |
| `audio.speech` | P4–P7 (expand) | #/media-prep → Audio → Studio | Typed actions + UI deep link |
| `audio.voices` | P3–P5 (core creative) | #/characters and Audio Studio | Typed actions + UI deep link |
| `audio.effects` | P4–P7 (expand) | #/media-prep → Audio → Studio effects/conversion | Typed actions + UI deep link |
| `audio.voice_studio` | Later (specialized / guard) | Audio Studio → specialist voice tools | Restricted typed actions; explicit authorization |
| `audio.scene` | P4–P7 (expand) | Audio Studio → scene surgery | Typed actions + UI deep link |
| `audio.reconstruct` | P4–P7 (expand) | #/media-prep → Audio → Reconstruct | Typed actions + UI deep link |
| `audio.finetune` | Later (specialized / guard) | Audio Studio → fine-tune preparation | Restricted typed actions; explicit authorization |
| `music.generate` | P4–P7 (expand) | #/media-prep → Audio → Music & Sound | Typed actions + UI deep link |
| `music.ace` | Later (specialized / guard) | Music & Sound → ACE-Step studio; nested view, not a guaranteed top-level hash route | Typed actions + UI deep link |
| `music.jukebox` | Later (specialized / guard) | Music & Sound → Music Jukebox | Typed actions + UI deep link |
| `editor.edit` | P2 (first tool slice) | #/editor | Typed actions + UI deep link |
| `editor.styles` | P4–P7 (expand) | #/editor → style | Typed actions + UI deep link |
| `editor.export` | P2 (first tool slice) | #/editor → export | Typed actions + UI deep link |
| `models.3d` | Later (specialized / guard) | #/image-to-3d or #/image-to-3d-pixal3d | Typed actions + UI deep link |
| `system.status` | P2 (first tool slice) | #/status | Typed actions + UI deep link |
| `system.knowledge` | P2 (first tool slice) | Prompting/Director settings and skill files | Typed actions + UI deep link |

Read the domain guides and `catalog.json` for details; never promote a glossary description into a model tool without a schema, adapter, capability, authorization and job/output contract.
