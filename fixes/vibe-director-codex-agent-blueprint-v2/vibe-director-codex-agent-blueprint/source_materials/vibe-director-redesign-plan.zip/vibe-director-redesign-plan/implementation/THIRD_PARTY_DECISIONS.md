# External Tool Decisions — OpenMontage, Backlot, HyperFrames

**Status:** Feasibility only. No external repository was installed or executed against the Vibe Director app.

## HyperFrames — near-term, controlled integration

**Already present in Vibe Director:** the reviewed `vibe_editor_render.py` converts an approved composition to trusted HTML/GSAP/HyperFrames inputs and renders in an isolated browser, with FFmpeg and output verification (`full_review.md` §16). Keep it.

**External option:** HyperFrames documents an embeddable/extendable `@hyperframes/studio` React package with timeline, preview, inspector, and optional `StudioApp`; some components require Studio context/server. Official docs distinguish CLI `preview/render` from standalone Studio imports. Validate the installed frontend React/Node versions, API/export signatures and the current renderer contract before choosing native component integration vs controlled localhost preview.

**Recommendation:**
1. First, put the *existing* Vibe Editor right-pane UI under the Codex shell and make its operations callable by Director.
2. Prototype `@hyperframes/studio` in a feature-flagged integration spike. Create a test composition from a Vibe Editor selected-media session, preview/scrub, persist edits, render, and return an owned validated output.
3. If Studio introduces incompatible state/file ownership, keep it an **Advanced Studio** isolated service, not a replacement timeline. Existing Editor remains the stable default.
4. Reuse app auth, project/grants, sandbox, media staging and output verification. Don't give the chat unrestricted shell/source-code edits to run `npx`.

Official materials: `https://hyperframes.app/docs/5-packages/studio`, `https://hyperframes.app/docs/5-packages/cli`, `https://github.com/heygen-com/hyperframes`.

## OpenMontage — optional pipeline adapter, do not migrate the app onto it

**What it offers:** agent-first knowledge/pipeline manifests, media retrieval and documentary montage workflows, cost/quality evaluation, compositing via Remotion/HyperFrames. Useful to borrow **ideas**: modular production-stage manifests, provider selection, output validation, self-review and researcher/repertoire mode. Existing Vibe Director already has many adjacent operations and a different durable ledger.

**Recommended order:**
1. Read specific OpenMontage modules/skills for desired capabilities only after choosing a defined use case, e.g. `find free footage and build a documentary montage`.
2. License/security review and dependency audit.
3. If permitted and useful, run OpenMontage as an **external process/adapter under a scoped workspace**, never with raw Vibe Director project/ledger write access. Exchange a normalized brief/manifests, authorized source media and registered output assets.
4. Add an optional `montage.external` tool with typed `propose/status/accept_result` operations and a separate readiness state. Do not count its provider inventory as installed Vibe Director capabilities.
5. Measure benefit against native `media.semantic + Editor + FFmpeg` first; keep native path for existing projects.

**License warning:** the `calesthio/OpenMontage` repository currently advertises **GNU AGPLv3**; third-party forks/copies may carry different licenses. Do not copy source or bundle a fork on the assumption every OpenMontage download is MIT. Have an actual license compatibility review before redistribution or creating a derivative/combined work. This note is not legal advice.

Official repo: `https://github.com/calesthio/OpenMontage`.

## Backlot — read-only view, not the comic storyboard

Backlot is OpenMontage's **read-only living storyboard/progress dashboard**. Its docs state it watches OpenMontage's project files (`project.json`, stage checkpoints, `scene_plan`, manifests and events) and exposes a local server (e.g. port 4750), with filesystem watcher/SSE. Those are *not* Vibe Director's SQLite project/production-ledger records.

**Recommendation:** build a Backlot-inspired **native Run Board** on existing Vibe Director job/events data. Preserve it as **read-only production progress and approval status**. The actual **Comic Storyboard** remains editable and stores panel assets separately. An embedded external Backlot GUI requires a deliberate translation/event bridge, authenticated localhost exposure review, parent-frame policy, project-owner mapping and data isolation tests; not simple iframe hope.

Official Backlot docs: `https://github.com/calesthio/OpenMontage/blob/main/backlot/README.md`.

## Decision table

| Feature | Recommendation | Priority | Gate before claiming shipped |
|---|---|---:|---|
| Existing Vibe Editor on right of persistent chat | Adapt existing UI/service | Now | Real selected asset → plan → preview → output |
| HyperFrames Studio in right pane | Feature-flagged proof of concept | Later | Supported versions, editing roundtrip, verified export |
| Backlot-like Run Board | Native UI on Vibe Director ledger | Soon | Real jobs/status/replay from app data |
| External Backlot GUI | Optional wrapper/adapter | Later | Project format translation and security |
| OpenMontage documentary/search pipelines | Optional external service | Later | Licensing, isolation and added-value proof |
| Replace whole Vibe Director with OpenMontage | **Do not do** | Never by default | Would jeopardize existing jobs/asset identity and user workflow |
