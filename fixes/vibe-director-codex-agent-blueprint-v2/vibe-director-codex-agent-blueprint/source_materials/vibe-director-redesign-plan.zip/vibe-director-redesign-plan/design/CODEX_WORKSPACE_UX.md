# Three-Pane Workspace — Product and Interaction Specification

**Design goal:** Codex-style operations with Vibe Director's existing palette, type scale and project identity. These are product specifications; not evidence of implemented features.

## A. Desktop shell (resizable and collapsible)

```text
┌ Project: Lion & Mouse ▼ ───────────────────────────────────── Job status ●  Settings ┐
│ ┌──── LEFT 18% ─────┐ ┌──────── CENTER 34% ────────┐ ┌──── RIGHT 48% ─────────────┐ │
│ │ Project           │ │ Director / Editor chat     │ │ Tabs: Prompt | Video | ...  │ │
│ │  • Story          │ │                           │ │                            │ │
│ │  • Screenplay     │ │ [user] Continue clip 4…   │ │  SCENE 5 — RESCUE          │ │
│ │  • Characters     │ │                           │ │  [15s] [R2V] [LTX OFF]     │ │
│ │  • Environments   │ │ [Director] Use refs:      │ │                            │ │
│ │  • Storyboard     │ │  mouse, lion, previous    │ │  Reference assets         │ │
│ │  • Prompt / Video │ │  last frame, lion voice  │ │  [mouse][lion][last frame] │ │
│ │  • Media Library  │ │                           │ │  [voice]                   │ │
│ │  • Media Prep     │ │ [tool card: frame ready]  │ │  Time beats                │ │
│ │  • Vibe Editor    │ │                           │ │  0–2 examine rope         │ │
│ │  • Run Board      │ │ [ready-to-review prompt]  │ │  2–6 chew                 │ │
│ │                     │ │                           │ │  ...                       │ │
│ │  Recent assets      │ │ Attach  Ask… [Send]       │ │  [Edit] [Validate] [Run]   │ │
│ └────────────────────┘ └───────────────────────────┘ └────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────────┘
```

On smaller screens: collapse left to a rail, let user toggle chat/workspace on top, and preserve both states. Maintain resizable gutters, meaningful min widths, keyboard focus/accessibility, visible errors and selection. Never discard unsaved right-pane edits when the Director opens a different tool; use named work tabs and dirty-state prompts.

## B. Left pane: project and tool navigation

Top: `Project name` + new/open/save (with active-job explanation), `Search assets`, job/status badge. Clear groups:

- **Write:** Story, Screenplay.
- **Design:** Characters, Environments, Storyboard.
- **Create:** Prompt Studio, Image Lab, Video Lab, Voices/Audio.
- **Edit:** Vibe Editor (timeline), Quick Assemble, Exports.
- **Library:** Project Media, Media Prep, Search, Run Board.
- **Advanced:** Workflow/Model settings, provider status, standalone tools.

Allow pins/favorites; never make this a sequential progress checklist. Show unobtrusive completion information only. A standalone tool remains usable with `tool-library` ownership if no project is selected; don't invent a fake story project.

## C. Middle pane: persistent Director chat

Chat is not a log pasted inside each individual page. Maintain one default project Director thread plus optional named conversations, each with tool action cards and a durable task ledger.

User may type:
- “Generate my mouse character using Z-Image.”
- “Here are two reference images and two voice identity samples. Make a 15-second H3 R2V prompt.”
- “The previous clip's lion is in a net. Extract its last frame and continue.”
- “Use this video, extract MP3, inspect the speech, and put the resulting selected sound in my Editor.”
- “Open the HyperFrames timeline for these accepted clips.”

Response parts: (1) precise plan/action, (2) chosen real refs with thumbnails/asset IDs, (3) proposed/actual tool jobs including progress, (4) result asset and route to surface. The chat can open right-pane tabs via a **typed navigation action**; the right pane remains interactive.

A durable tool-card shows `Pending`, `Running`, `Needs review`, `Completed`, `Blocked` or `Failed`. A Director cannot mark `Completed` until real output is verified or the task is explicitly a draft-only response. “Go ahead” should approve the previously proposed exact action/version, not unconstrained future behavior.

## D. Right pane: renderable work tabs

Use existing React pages as the foundation, not screenshots. Potential tabs: `Storyboard`, `Prompt`, `Image`, `Video`, `Media Prep`, `Editor`, `Asset Inspector`, `Jobs`, `Run Board`.

`navigation.open` carries typed context:

```json
{
  "target": "video.prompt",
  "projectId": "<canonical-owner>",
  "assetIds": ["<real-id-a>", "<real-id-b>"],
  "clipDraftId": "<persisted-draft-id>",
  "conversationId": "<chat-thread-id>",
  "openMode": "reuse_or_new_tab"
}
```

This is a proposed app-specific navigation contract, **not an existing API**. The page must adopt context, show the selected references and reflect changes back to chat/project state. Avoid made-up hash URLs. Browser website embedding needs separate security/auth/browser policy; do not imply arbitrary sites allow iframes.

## E. Storyboard: the fast comic-book experience

Visual layout is *scene pages* rather than form rows:

```text
SCENE 04 · FOREST · 15s                              [Generate missing images]
┌──────────────────────┐ ┌──────────────────────┐ ┌──────────────────────┐
│   IMAGE PANEL 01     │ │   IMAGE PANEL 02     │ │   IMAGE PANEL 03     │
│ [lion tangled in net]│ │ [mouse hears lion]   │ │ [mouse running]      │
├──────────────────────┤ ├──────────────────────┤ ├──────────────────────┤
│ 0–3s  ·  Wide        │ │ 3–7s  ·  Close       │ │ 7–12s · Tracking     │
│ Action: Lion trapped │ │ Mouse: “He's hurt!”  │ │ Action: Run to lion  │
│ [Edit] [Redo] [Use]  │ │ [Edit] [Redo] [Use]  │ │ [Edit] [Redo] [Use]  │
└──────────────────────┘ └──────────────────────┘ └──────────────────────┘
```

Images never contain hard-baked dialogue text; UI speech bubbles/caption bars sit outside image assets. Panels carry actor IDs, voice IDs, camera notes, duration and shot group. A **single continuous video** can be represented by multiple panels, with `group: one_take`. Panel commands: Edit description; regenerate image with refs; choose alternate take; regenerate only panel; split/merge; drag reorder; prepare opening frame; create prompt/clip; send selected items to Editor; export comic page. On render, reuse existing Storyboard page persistence where valid.

### Storyboard speed policy

Default to quick low-cost images or manual uploaded images, not final-quality multi-view art on every panel. Render a usable full story quickly; approval/refinement comes later. Cache approved image refs, prompt versions and hashes. Closing the browser must not stop admitted backend image work. Only generate what the user requests; unprepared pages can show visual placeholders explicitly labeled.

## F. Prompt page: exactly the user's reference-first style

Panel 1 — **References to use**:

| Slot | Selected asset | Semantic role | Validation |
|---|---|---|---|
| `<Picture 1>` | mouse master | Mouse identity | ✅ Registered image |
| `<Picture 2>` | lion master | Lion identity | ✅ Registered image |
| `<Picture 3>` | previous clip last frame | Opening composition **reference** | ✅ Image, not hard R2V first frame |
| `<audio1>` | lion voice WAV | Lion voice identity, not dialogue file | ✅ Supported reference |

`<Picture>`, `<Video>`, `<audio>` slots are independently numbered by selected type, and the UI must regenerate/cross-check tokens when ordering changes. Persist real asset IDs separately; the token is presentation, not identity. Allow drag-reorder and per-asset reference instructions. Don't include audio if nobody speaks.

Panel 2 — **15-second beat timeline**:

| Time | Physical action and blocking | Camera | Voice/SFX |
|---|---|---|---|
| 0–2 | Mouse examines rope | Maintain opening composition; push in | Forest |
| 2–6 | Mouse gnaws visible fibers | Low close-up | Rope fibers |
| 6–9 | Rope snaps and net loosens | Pull back/rise | Snap |
| 9–12 | Lion stands free | Medium-wide | Net rustles |
| 12–15 | Lion says thanks | Intimate two-shot | `<audio1>` generated voice |

Panel 3 — **Rendered generator prompt**: copyable editable text, `chars 4,289 / 6,999 max` (codepoints), `duration 15 / 15`, `R2V (5–15s)`, `references 3/9 images · 0/3 videos · 1/3 audio`, precise model validator errors. Include soundscape and `non_diegetic_music: N/A`. Allow draft preview and actual generation separately; changes to accepted drafts should create a new version/take.

## G. Video page / Current Take

Visible top row: route, model profile, quality path `H3 Turbo (original)` or `H3 + LTX (refined)`, duration, status and actual blocker. Tabs `Create`, `Take Review`, `History`, `References`. Actions: Extract last frame → view registered image → Use as reference in next clip; Retake (new draft), Accept, Send to Editor. If pending uncertain attempt, show **Recover / Release safely** and the owning job ID, not global cards silently grayed out.

## H. Editor page with persistent chat

Main Director chat stays in middle; **right pane** hosts a timeline/preview with selected media. Separate `Quick edit` (existing restricted validated JSON composition) from `Advanced HyperFrames Studio` (only when supported version/bridge tests succeed). Director can request an edit, proposal/brief and plan; user sees approved time ranges and rendered output. Add "Open Media Prep" and "Extract MP3" as real cross-tool actions, not claims that the renderer cannot do these.

## I. Living production / Backlot-like Run Board

A separate right-pane **read-only Run Board** pulls from Vibe Director's existing jobs/ledger: stage/task cards, submitted attempts, assets, blocker, spend/resource where known, rerenders and output. It is **not the comic storyboard** and not an alternative source of truth. If an external Backlot GUI is launched, label it `External Backlot`, and only expose when a tested localhost/project bridge exists.

## J. Accessibility, keyboard, and reliability

- `Cmd/Ctrl+K` command palette: search pages/tools/assets/actions.
- `Enter` to send; explicit `Generate` to launch jobs where authorization requires it.
- Drag attachments into chat or right-pane pickers. Chips show real kind/id and provenance.
- Show every failure with item, cause, next action, and linked job ID.
- Loading indicators refer to live job stage, not indefinite “thinking”.
- On project switch, snapshot unsaved drafts; prevent late callbacks from crossing owner boundaries.
- Page selection and assistant selection stay synchronized but never overwrite unsaved user edits without consent.
